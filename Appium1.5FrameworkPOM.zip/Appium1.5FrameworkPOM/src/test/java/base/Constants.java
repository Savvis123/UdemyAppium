package base;

public class Constants {
	
	
	//MAKE MY TRIP LOCATORS
	
	public static final String CHART1 = "//UIAApplication[1]/UIAWindow[2]/UIATableView[1]/UIATableCell[1]/UIAStaticText[1]";
	public static final String LAYOUT = "com.makemytrip:id/slide_view_root_layout";
	public static final String MENU_ITEMS = "com.makemytrip:id/menu_txv";
	public static final String FROM_CITY = "com.makemytrip:id/from_code";
	public static final String TO_CITY = "com.makemytrip:id/to_code";
	public static final String TO_FRO_CITY_LIST = "com.makemytrip:id/toFroListCity";
	public static final String CITY_NAME = "com.makemytrip:id/cityName";
	
	public static final String FROM_DAY = "com.makemytrip:id/from_day";
	public static final String CAL_TITLE = "com.makemytrip:id/title";
	public static final String NEXT_MONTH = "com.makemytrip:id/calViewNextMonth";
	





}
