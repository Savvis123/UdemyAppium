package screens.care;

public class TypeOfCareGiverScreen {
	
	
	public void selectTypeOfCare(String care){
		
		
	}

}
