package screens.care;

public class TypeOfCareJobScreen {

	public void selectTypeOfCareJob(String care) {

	}

}
